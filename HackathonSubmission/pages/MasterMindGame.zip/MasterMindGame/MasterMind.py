from random import choices
from time import sleep


def check_positions(user_guess, correct_code):
    correct_position = 0
    incorrect_position = 0

    for i, j in zip(user_guess, correct_code):
        if i == j:
            correct_position += 1
        else:
            incorrect_position += 1

    return correct_position, incorrect_position


# colors are Aqua, Magenta, Crimson, Violet, Pink, Emerald
COLORS = ["A", "M", "C", "V", "P", "E"]
tries = 15

code = choices(COLORS, k=4)

print("Welcome to MasterMind game. Attempt to guess 4 digit code... You have 10 tries")
print("The colours that couldn't make up the code are: R G B Y W O")
print("Hint: The colours that could make up the code are not very popular")

while tries != 0:
    guess = input("Guess (space separated): ").upper().split(" ")
    tries -= 1

    if tries == 0:
        print("You lost....")
        print(f"The code was {code}")

    if guess == code:
        print("You Won!")
        print(f"{tries} tries were left.")

        if input("Wanna play again?(y/n): ").lower() == "n":
            break
        else:
            code = choices(COLORS, k=4)
            tries = 15

    else:
        correct_pos, incorrect_pos = check_positions(guess, code)
        print(f"Correct Position: {correct_pos} | Incorrect Position: {incorrect_pos}")

print("Thanks for playing!")
sleep(2)
