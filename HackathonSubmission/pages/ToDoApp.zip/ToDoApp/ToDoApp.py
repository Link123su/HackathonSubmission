from tkinter import *
import os
import pickle
from random import choice
from tkinter.messagebox import showinfo


# this function will find monkey image path
def find_image(image_name):
    # Start search from the root directory
    if os.name == 'nt':  # Windows
        search_path = 'C:\\'
    else:  # Unix/Linux/Mac
        search_path = '/'

    # Use glob to recursively search for the file
    for root, dirs, files in os.walk(search_path):
        if image_name in files:
            return os.path.join(root, image_name)

    return None


# monkey image path
monkey_image_path = find_image("Mr.Monkey.png")


# this function will return loaction of document folder in user's Pc
def get_document_folder() -> str:
    documents_path = ""
    if os.name == 'nt':  # Windows
        documents_path = os.path.join(os.getenv('USERPROFILE'), 'Documents')

    return documents_path if os.path.exists(documents_path) else None


# specifing folders locations
TODO_FOLDER_PATH = f"{get_document_folder()}\\TODO_Data"
PICKLE_FILE_PATH = f"{TODO_FOLDER_PATH}\\data.pickle"

# creating TODO FOlDER if not exits
if not os.path.exists(TODO_FOLDER_PATH):
    os.mkdir(TODO_FOLDER_PATH)

# creating pickle file to store data
if not os.path.exists(PICKLE_FILE_PATH):
    with open(PICKLE_FILE_PATH, "wb") as f:
        pickle.dump(["Subscribe to PythonicMind"], f)


# this will return a random task
def get_random_task() -> str:
    # list containing some random tasks
    random_tasks_list = ['Code a Todo app', 'Paint your house', 'Climb a Mountain', 'Eat something',
                     'Play NumberGuessing game', 'Climb a Tree', 'Learn Coding', 'Subscribe To PythonicMind',
                     'Call a Friend', 'Clean your house', 'Learn React.js', 'Use Notepad as your Code Editor',
                     'Install VS code', 'Visit Zoo', 'Learn Kotlin', 'Learn Java', 'Play Chess', 'Change clothes',
                     'Learn Go', 'Go 100km away from your house', 'Vist your nearest park',
                     'Subscribe To Coding With Lewis', 'Play a game', 'Buy a cat', 'Give a Banana To Mr.Monkey',
                     'Create a bot', 'Learn Python', 'Play RockPaperScissor game', 'Install Python',
                     'Touch some grass', 'Learn Rust', 'Delete any app and reinstall it', 'Calculate Your BMI',
                     'Code a website', 'Learn Swift']
    
    # selecting a random task
    random_task = choice(random_tasks_list)

    # returning random task 
    return random_task


def meet_monkey_window() -> None:
    try:
        # creating a toplevel window
        top = Toplevel()
        # specifying geometry and title
        top.geometry("750x600")
        top.title("Meet Mr.Monkey")

        # creating PhotoImage
        img = PhotoImage(file=monkey_image_path)
        # creating label to display Photo
        img_label = Label(top, image=img)
        img_label.pack()

        # Monkey's message
        msg = """Meet Mr.Naughty Monkey. He deliberately adds random tasks to your to-do list.
                He challenged you to manage your tasks despite the chaos. 🐵"""
        
        # creating label to display message
        msg_label = Label(top, text=msg, font=("bold", 14,"bold"))
        msg_label.pack()

        # creaeting exit button
        ok_button = Button(top, text="Ok", font=("bold", 15, "bold"), fg="white", activeforeground="white",
                        bg="#349eeb", activebackground="#349eeb", command=lambda: top.destroy())
        ok_button.pack()

        top.mainloop()
    except Exception:
        # in case of error, it will show this
        showinfo(title="Mr.Monkey is not here", message="Mr.Naughty Monkey is not here.")


def add_task() -> None:
    # getting user input
    task = task_input.get()

    # if task is not empty
    if not task == "":
        # inserting task into list box
        list_box.insert(END, task)

        # inserting a random task into list box
        list_box.insert(END, get_random_task())

        # deleting user input entry
        task_input.delete(0, END)

        # calling save function to save changes
        save()


def delete_task() -> None:
    try:
        # getting current selection of user from list box
        task = list_box.get(ACTIVE)
        # getting index of task
        task_index = list_box.get(0, END).index(task)
        # deleting task from listbox
        list_box.delete(task_index)

        # calling save function to save changes
        save()
    except Exception:
        pass


def save() -> None:
    # getting all the elements from list box
    data = list(list_box.get(0, END))

    # opening Pickle file
    file = open(PICKLE_FILE_PATH, "wb")
    # adding data to pickle file
    pickle.dump(data, file, protocol=pickle.HIGHEST_PROTOCOL)
    # closing file
    file.close()


def load() -> None:
    # opening pickle file in read binary mode
    file = open(PICKLE_FILE_PATH, "rb")
    # loeading data from pickle file
    data = pickle.load(file)
    # closing file
    file.close()

    # inserting data in listbox
    for task in data:
        list_box.insert(0, task)


# creating window
window = Tk()
# specifing window geometry
window.geometry("750x750")
# specifing window tite
window.title("ToDo App")

# creating meny bar
menu_bar = Menu(window)
# add meet_monkey option
meet_monkey = Menu(menu_bar, tearoff = 0)
# adding command to meet_monkey option
menu_bar.add_command(label ="Meet Monkey", command=meet_monkey_window)

# adding menu bar to window
window.config(menu=menu_bar)

# creating label to display title 
title = Label(window, text="ToDo App", font=("bold", 30, "bold"))
title.pack()

# creating listbox to display tasks
list_box = Listbox(window, height=20, width=25, relief=FLAT, font=("bold", 15, "bold"))
list_box.pack(side=RIGHT, padx=10, pady=10)

# creating frame to display buttons and entry
button_frame = Frame(window)
button_frame.pack(side=LEFT, padx=10, pady=10)

# creating label
task_label = Label(button_frame, text="Add Task", font=("bold", 20))
task_label.grid(row=0, column=0, padx=5, pady=5)

# creating Entry to take user input
task_input = Entry(button_frame, font=("bold", 15), relief=FLAT)
task_input.grid(row=0, column=1, padx=5, pady=5)

# Specifing Button styles
BUTTON_FONT = ("bold", 15, "bold")
BUTTON_FG_COLOUR = "white"
BUTTON_BG_COLOUR = "#349eeb"
BUTTON_RELIEF = FLAT

# creating Add button, this will call add_task function
add_btn = Button(button_frame, text="Add Task", font=BUTTON_FONT, fg=BUTTON_FG_COLOUR,
                 activeforeground=BUTTON_FG_COLOUR, bg=BUTTON_BG_COLOUR, activebackground=BUTTON_BG_COLOUR,
                 relief=BUTTON_RELIEF, command=add_task)
add_btn.grid(row=1, column=0, padx=20, pady=20)

# creating Delete button, this will call delete_task function
delete_btn = Button(button_frame, text="Delete Task", font=BUTTON_FONT, fg=BUTTON_FG_COLOUR,
                    activeforeground=BUTTON_FG_COLOUR, bg=BUTTON_BG_COLOUR, activebackground=BUTTON_BG_COLOUR,
                    relief=BUTTON_RELIEF, command=delete_task)
delete_btn.grid(row=1, column=1, padx=20, pady=20)

# calling load function to load the data
load()

# displaying window
window.mainloop()
